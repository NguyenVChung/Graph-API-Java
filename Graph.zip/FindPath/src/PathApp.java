import java.util.Scanner;

public class PathApp {
    static Scanner sc;
	public static void main(String[] args) {
		Graph theGraph = new Graph();
		theGraph.adVertex("Kim Ma");
		theGraph.adVertex("Pho Co");
		theGraph.adVertex("Le Duan");
		theGraph.adVertex("Lang");
		
		theGraph.adEdge(0, 1, 5); //Kim MA - Pho Co
		
		theGraph.adEdge(0, 2, 1); //KIM MA - Le Duan
		
		theGraph.adEdge(0, 3, 2); //Kim MA - Lang
		
		theGraph.adEdge(1, 2, 3); //Pho Co - Le Duan
		
		theGraph.adEdge(2, 3, 26); //Le Duan - Lang
		
		int menu = 0;
		do {
		do {
			try {
				System.out.println("\n--------menu--------");
                System.out.println("1. Enter 1 to find stations and min path");
                System.out.print("Please choose: ");

                sc = new Scanner(System.in);
                menu = sc.nextInt();
                break;
                } catch (Exception e) {
                    System.out.println("Please choose menu 1, 2, 3 or 4");
                }
            } while (true);

            switch (menu) {
            case 1:
            	System.out.println("************************************************");
        		theGraph.path();
        		System.out.println(" ");
                break;
            case 2:
    			break;
    		default:
    			System.out.println("Please enter 1, 2,3,4");
    			break;
            }
		 } while (menu != 0);
		}
}
