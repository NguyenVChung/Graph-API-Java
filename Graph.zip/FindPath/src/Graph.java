import java.util.Scanner;

public class Graph {
    private final int mazVert = 10;
    private final int infinity = 1000000;
    private Vertex vertexList[];
    private int adjMat[][];
    private int nVert;
    private Vertex middleVertex;
    
    private Scanner sc;
    
	public Graph() {
		vertexList = new Vertex[mazVert];
		
		adjMat = new int[mazVert][mazVert];
		nVert = 0;
		for(int j = 0; j < mazVert; j++){
			for(int k = 0; k < mazVert; k++){
				adjMat[j][k] = infinity;
			}
		}
	}
	
	//add vertex
	public void adVertex(String lab){
		vertexList[nVert++] = new Vertex(lab);
	}
	
	//adEdge
	public void adEdge(int start, int end, int weight){
		adjMat[start][end] = weight;
		adjMat[end][start] = weight;
	}

	public void path(){
		int start = startVertex();
		int end = endVertex();
		int minPaths = getMinPath(start, end);
		
		String parent = vertexList[end].label; 
		
		
		if(minPaths == infinity){
			System.out.print("Not be reached. Please enter another station name!");
		}else{
			System.out.println("");
			System.out.println("**********************");
			System.out.print("From " + vertexList[start].label + " to " + parent + ": " + minPaths + " (km)");
		}
		System.out.println(" ");
	}
	
	//start vertex
		public int startVertex(){
			sc = new Scanner(System.in);
			System.out.print("Enter Start Station: ");
			String st = sc.nextLine();
			
			int startIndex = -1;
			for(int i = 0; i < nVert; i++){
				if(st.toLowerCase().equals(vertexList[i].label.toLowerCase())){
					startIndex = i;
				}
			}
			return startIndex;
		}
		
		//end vertex
		public int endVertex(){
			sc = new Scanner(System.in);
			System.out.print("Enter End Station: ");
			String en = sc.nextLine();
			
			int ed = -1;
			for(int i = 0; i < nVert; i++){
				if(en.toLowerCase().equals(vertexList[i].label.toLowerCase())){
					ed = i;
				}
			}
			return ed;
		}
	
	public int getMinPath(int s, int e){
		int start = s;
		int end = e;
		int temp = 0; 
		int middleToEnd = 0;
		
		int minDistance = infinity;
		if(adjMat[start][end]  != infinity){
			minDistance = adjMat[start][end];
			System.out.println("No middle station. 2 stations are connected straightly");
		}else{
			for(int i = 1; i < nVert; i++){
				if(adjMat[start][i-1] > adjMat[start][i]){
					temp = adjMat[start][i];
					
				}
				if(adjMat[i-1][end] > adjMat[i][end]){
					middleToEnd = adjMat[i][end];
					
				}
				middleVertex = vertexList[i-1];
			}
			
			minDistance = temp + middleToEnd;
			System.out.println("");
			System.out.println("Middle Station: " + middleVertex.label);
		}
		
		return minDistance;
	}
}

