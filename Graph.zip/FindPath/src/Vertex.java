
public class Vertex {
    public String label;
    
	public Vertex(String lab) {
		label = lab;
	}

}
